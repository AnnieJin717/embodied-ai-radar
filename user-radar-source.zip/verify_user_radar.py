"""Exercise the matching HTTP workflow with a simulated OpenAI-compatible provider."""
import json
from io import BytesIO
from unittest.mock import patch
from wsgiref.util import setup_testing_defaults

from src.user_radar import server
from src.user_radar.matching import Model


HUMANOID = "人形机器人本体"
SECTOR = dict(label="人形本体", field="sub_tracks", op="in", values=[HUMANOID], required=True, weight=3)
STAGE = dict(label="A 轮前", field="funding_stage", op="before", values=["A"], required=True, weight=3)
TEAM = dict(label="有团队工作背景", field="semantic", op="evidence", values=[], required=True, weight=2)
UNKNOWN = dict(TEAM, label="不存在的学校背景")


class Provider(Model):
    key = "fixture-token"
    chat_model = "fixture-chat"
    embedding_model = "fixture-embed"

    def __init__(self):
        pass

    def post(self, route, payload):
        if route == "/embeddings":
            result = {"data": [{"index": i, "embedding": [1.0, float("team_work" in text)]}
                               for i, text in enumerate(payload["input"])]}
        else:
            assert route == "/chat/completions"
            prompt = payload["messages"][0]["content"]
            context = json.loads(payload["messages"][1]["content"])
            if prompt.startswith("Convert"):
                query = context["query"]
                if query == "首页样例":
                    result = {"action": "search", "criteria": [SECTOR, STAGE]}
                elif query == "宽筛选":
                    result = {"action": "search", "criteria": [SECTOR]}
                elif query == "加条件":
                    assert context["prior_criteria"] == [SECTOR, STAGE]
                    result = {"action": "refine", "criteria": [*context["prior_criteria"], TEAM]}
                elif query == "对比":
                    result = {"action": "compare", "count": 2}
                elif query == "为什么":
                    result = {"action": "explain", "count": 1}
                elif query == "无结果":
                    result = {"action": "search", "criteria": [SECTOR, UNKNOWN]}
                else:
                    result = {"action": "invalid"}
            elif prompt.startswith("Assess"):
                rules = context["criteria"]
                rows = []
                for company in context["companies"]:
                    experience = company["facts"].get("team_work", [])
                    checks = [{"index": rule["index"], "status": "met" if experience else "unknown",
                               "field": "team_work",
                               "quote": "invented citation" if rule["label"] == UNKNOWN["label"] else
                               experience[0][:100] if experience else ""}
                              for rule in rules]
                    rows.append({"id": company["id"], "checks": checks})
                result = {"rows": rows}
            else:
                result = {"facts": [{"id": row["id"], "field": "name", "quote": row["name"]}
                                    for row in context["companies"]]}
            result = {"choices": [{"finish_reason": "stop", "message": {"content": json.dumps(result)}}]}
        return result


def verify():
    cookie = ""

    def request(path, payload=None, status=200, use_cookie=True):
        nonlocal cookie
        data = json.dumps(payload).encode() if payload is not None else b""
        environ = {"REQUEST_METHOD": "POST" if payload is not None else "GET", "PATH_INFO": path,
                   "CONTENT_TYPE": "application/json", "CONTENT_LENGTH": str(len(data)),
                   "REMOTE_ADDR": "127.0.0.1", "HTTP_COOKIE": cookie if use_cookie else "",
                   "wsgi.input": BytesIO(data)}
        setup_testing_defaults(environ)

        def capture(actual, headers):
            nonlocal cookie
            assert int(actual.split()[0]) == status, (actual, path)
            if value := dict(headers).get("Set-Cookie"):
                cookie = value.split(";")[0]

        raw = b"".join(server.application(environ, capture)).decode()
        return json.loads(raw) if path != "/" else raw

    def query(text, follow_up=False, status=200, use_cookie=True):
        return request("/api/matching/query", {"query": text, "follow_up": follow_up}, status, use_cookie)

    with patch.object(server, "Model", Provider):
        server.workflow.cache_clear()
        assert request("/healthz")["status"] == "ok"
        assert "AI 智能匹配" in request("/")
        info = request("/api/matching/info")
        assert info["companies"] >= 60 and info["live_model_configured"]
        result = query("首页样例")
        assert result["results"], "The sample should return pre-Series A humanoid companies"
        assert all(row["score"] == 100 and all(check["evidence"] for check in row["checks"])
                   for row in result["results"])
        first = result["results"][0]["id"]
        assert request("/api/matching/companies/" + first)["name"] == result["results"][0]["name"]
        refined = query("加条件", True)
        assert refined["action"] == "refine" and refined["results"]
        assert all(any(c["evidence"]["field"] == "team_work" for c in row["checks"])
                   for row in refined["results"])
        assert query("为什么", True)["answer"]
        assert query("宽筛选")["total_results"] >= 2
        compared = query("对比", True)
        assert compared["action"] == "compare" and len({x["id"] for x in compared["answer"]}) == 2
        assert not query("无结果")["results"], "The simulated judge's fabricated quote must not count"
        query("对比", True, 409, use_cookie=False)
        query("无法解释的输入", status=422)
    with patch.dict("os.environ", {"MATCH_LLM_API_KEY": "", "USER_RADAR_DEMO_PASSWORD": ""}):
        server.workflow.cache_clear()
        query("首页样例", status=503)
    print(f"PASS: {info['companies']} companies ({info['snapshot']}), "
          f"{result['total_results']} structured matches, {refined['total_results']} refined matches.")


if __name__ == "__main__":
    verify()
