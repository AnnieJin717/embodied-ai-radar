"""Exercise the matching HTTP workflow with a simulated OpenAI-compatible provider."""
import json
from decimal import Decimal
from io import BytesIO
from unittest.mock import patch
from wsgiref.util import setup_testing_defaults

from src.user_radar import server
from src.user_radar.matching import Model, Unavailable
from src.user_radar.valuation import query_rules, reported


HUMANOID = "人形机器人本体"
SECTOR = dict(label="人形本体", field="sub_tracks", op="in", values=[HUMANOID], required=True, weight=3)
STAGE = dict(label="A 轮前", field="funding_stage", op="before", values=["A"], required=True, weight=3)
TEAM = dict(label="有团队工作背景", field="semantic", op="evidence", values=[], required=True, weight=2)
UNKNOWN = dict(TEAM, label="不存在的学校背景")


class Provider(Model):
    key = "fixture-token"
    chat_model = "fixture-chat"
    embedding_model = "fixture-embed"

    def __init__(self):
        pass

    def post(self, route, payload):
        if route == "/embeddings":
            result = {"data": [{"index": i, "embedding": [1.0, float("team_work" in text)]}
                               for i, text in enumerate(payload["input"])]}
        else:
            assert route == "/chat/completions"
            prompt = payload["messages"][0]["content"]
            context = json.loads(payload["messages"][1]["content"])
            if prompt.startswith("Convert"):
                query = context["query"]
                if query == "首页样例":
                    result = {"action": "search", "criteria": [SECTOR, STAGE]}
                elif query in ("宽筛选", "人形本体"):
                    result = {"action": "search", "criteria": [SECTOR]}
                elif query == "加条件":
                    assert context["prior_criteria"] == [SECTOR, STAGE]
                    result = {"action": "refine", "criteria": [*context["prior_criteria"], TEAM]}
                elif query == "对比":
                    result = {"action": "compare", "count": 2}
                elif query == "为什么":
                    result = {"action": "explain", "count": 1}
                elif query == "无结果":
                    result = {"action": "search", "criteria": [SECTOR, UNKNOWN]}
                else:
                    result = {"action": "invalid"}
            elif prompt.startswith("Assess"):
                rules = context["criteria"]
                rows = []
                for company in context["companies"]:
                    experience = company["facts"].get("team_work", [])
                    checks = [{"index": rule["index"], "status": "met" if experience else "unknown",
                               "field": "team_work",
                               "quote": "invented citation" if rule["label"] == UNKNOWN["label"] else
                               experience[0][:100] if experience else ""}
                              for rule in rules]
                    rows.append({"id": company["id"], "checks": checks})
                result = {"rows": rows}
            else:
                result = {"facts": [{"id": row["id"], "field": "name", "quote": row["name"]}
                                    for row in context["companies"]]}
            result = {"choices": [{"finish_reason": "stop", "message": {"content": json.dumps(result)}}]}
        return result


def verify():
    cookie = ""

    def request(path, payload=None, status=200, use_cookie=True):
        nonlocal cookie
        data = json.dumps(payload).encode() if payload is not None else b""
        environ = {"REQUEST_METHOD": "POST" if payload is not None else "GET", "PATH_INFO": path,
                   "CONTENT_TYPE": "application/json", "CONTENT_LENGTH": str(len(data)),
                   "REMOTE_ADDR": "127.0.0.1", "HTTP_COOKIE": cookie if use_cookie else "",
                   "wsgi.input": BytesIO(data)}
        setup_testing_defaults(environ)

        def capture(actual, headers):
            nonlocal cookie
            assert int(actual.split()[0]) == status, (actual, path)
            if value := dict(headers).get("Set-Cookie"):
                cookie = value.split(";")[0]

        raw = b"".join(server.application(environ, capture)).decode()
        return json.loads(raw) if path != "/" else raw

    def query(text, follow_up=False, status=200, use_cookie=True):
        return request("/api/matching/query", {"query": text, "follow_up": follow_up}, status, use_cookie)

    with patch.object(server, "Model", Provider):
        server.workflow.cache_clear()
        assert request("/healthz")["status"] == "ok"
        assert "AI 智能匹配" in request("/")
        info = request("/api/matching/info")
        assert info["companies"] >= 60 and info["live_model_configured"]
        result = query("首页样例")
        assert result["results"], "The sample should return pre-Series A humanoid companies"
        assert all(row["score"] == 100 and all(check["evidence"] for check in row["checks"])
                   for row in result["results"])
        first = result["results"][0]["id"]
        assert request("/api/matching/companies/" + first)["name"] == result["results"][0]["name"]
        refined = query("加条件", True)
        assert refined["action"] == "refine" and refined["results"]
        assert all(any(c["evidence"]["field"] == "team_work" for c in row["checks"])
                   for row in refined["results"])
        assert query("为什么", True)["answer"]
        assert query("宽筛选")["total_results"] >= 2
        compared = query("对比", True)
        assert compared["action"] == "compare" and len({x["id"] for x in compared["answer"]}) == 2
        assert not query("无结果")["results"], "The simulated judge's fabricated quote must not count"
        query("对比", True, 409, use_cookie=False)
        query("无法解释的输入", status=422)
        assert query("找估值低于20亿人民币的项目")["mode"] == "local"
        hybrid = query("估值低于150亿且人形本体")
        assert hybrid["mode"] == "model" and hybrid["total_results"] == 4
        assert {rule["field"] for rule in hybrid["criteria"]} == {"valuation", "sub_tracks"}
    with patch.dict("os.environ", {"MATCH_LLM_API_KEY": "", "USER_RADAR_DEMO_PASSWORD": ""}):
        server.workflow.cache_clear()
        assert request("/api/matching/info")["local_matching_available"]
        exact = query("我想要创始人是清华大学毕业的项目")
        names = {row["name"] for row in exact["results"]}
        assert exact["mode"] == "local" and "银河通用" in names and "众擎机器人" not in names
        assert all("清华大学" in row["checks"][0]["evidence"]["quote"] for row in exact["results"])
        compared = query("对比前两家", True)
        assert len({fact["id"] for fact in compared["answer"]}) == 2
        assert query("只要做人形本体的", True)["action"] == "refine"
        assert query("A 轮前、做人形本体，团队最好有海外背景")["criteria"][2]["required"] is False
        query("排除清华校友", status=422)
        query("无法解释的输入", status=422)
    with patch.object(server, "Model", Provider), patch.object(Provider, "post", side_effect=Unavailable):
        server.workflow.cache_clear()
        assert query("我想要创始人是清华大学毕业的项目")["total_results"] == exact["total_results"]
    with patch.dict("os.environ", {"MATCH_LLM_API_KEY": "", "USER_RADAR_DEMO_PASSWORD": ""}):
        server.workflow.cache_clear()
        valuation_tests(query)
    print(f"PASS: missing and unavailable hosted model, exact screenshot query, {exact['total_results']} local matches.")
    print(f"PASS: {info['companies']} companies ({info['snapshot']}), "
          f"{result['total_results']} structured matches, {refined['total_results']} refined matches.")


def valuation_tests(query):
    threshold = Decimal("2000000000")
    exact = reported("官方披露投后20亿元（2026-10）")
    assert not exact.satisfies("lt", threshold) and exact.satisfies("le", threshold)
    assert exact.satisfies("ge", threshold) and not exact.satisfies("gt", threshold)
    assert reported("低于20亿元").satisfies("lt", threshold)
    assert not reported("15亿至25亿元").satisfies("lt", threshold)
    assert reported("10亿至19.5亿元").satisfies("lt", threshold)
    assert not reported("突破10亿元").satisfies("lt", threshold)
    assert reported("官方披露超30亿美元").currency == "USD"
    assert reported("官方披露10亿港元").currency == "HKD"
    assert reported("官方披露10亿日元") is None
    assert reported("未公开（2019年估值约为2018年收入的12倍）") is None
    assert reported("上市公司市值为10亿元") is None
    assert not reported("IPO前估值18.6亿元、上市后估值20.8亿元（另有旧估值18.18亿元）").satisfies("lt", threshold)
    for wording in ("估值低于20亿人民币", "估值＜200000万元", "估值低于人民币2000百万",
                    "valuation below CNY 2 billion", "估值不超过20亿元", "估值20亿以下"):
        parsed, _ = query_rules(wording)
        assert len(parsed) == 1 and Decimal(parsed[0]["amount"]) == threshold
    empty = query("找估值低于20亿人民币的项目")
    assert empty["total_results"] == 0 and empty["valuation_counts"]["unknown"] > 0
    strict = query("找估值低于150亿人民币的项目", False)
    inclusive = query("改成不超过150亿", True)
    assert strict["total_results"] < inclusive["total_results"]
    assert query("find companies with valuation below CNY 15 billion")["total_results"] == strict["total_results"]
    window = query("估值在100亿到150亿之间")
    assert len(window["criteria"]) == 2 and window["results"]
    assert all(check["status"] == "met" for row in window["results"] for check in row["checks"])
    combined = query("估值低于150亿，人形本体")
    assert 0 < combined["total_results"] < strict["total_results"]
    assert all(len(row["checks"]) == 2 and all(c["evidence"] for c in row["checks"]) for row in combined["results"])
    narrowed = query("估值高于100亿且不超过150亿", True)
    assert {r["field"] for r in narrowed["criteria"]} == {"sub_tracks", "valuation"}
    assert sum(r["field"] == "valuation" for r in narrowed["criteria"]) == 2
    assert query("对比前两家", True)["action"] == "compare"
    query("估值低于150亿或做人形本体", status=422)
    query("估值低于150亿且人形本体且员工超过一万", status=422)
    query("估值低于20", status=422)
    print(f"PASS: exact valuation query -> 0 confirmed, {empty['valuation_counts']['unknown']} unknown; "
          f"strict 150 -> {strict['total_results']}, inclusive -> {inclusive['total_results']}, "
          f"compound -> {combined['total_results']}.")


if __name__ == "__main__":
    verify()
