# MIS3011 具身项目雷达 · 用户端 F5 智能匹配

2026 年 11 月 27 日工作流验收交付，负责人 Silence。

## 启动

在解压目录使用 Python 3.11 或更高版本。匹配工作流和本地测试使用 Python 标准库。

```powershell
python verify_user_radar.py
$env:MATCH_LLM_BASE_URL = 'https://api.openai.com/v1'
$env:MATCH_LLM_MODEL = '<组内配置的对话模型>'
$env:MATCH_EMBEDDING_MODEL = '<组内配置的向量模型>'
# 通过本机环境设置 MATCH_LLM_API_KEY
python -m src.user_radar.server
```

打开 http://127.0.0.1:8013/。OpenAI 兼容服务需要同时提供 Chat Completions 和 Embeddings，并支持 JSON 对象输出。实际模型和密钥使用组内账号配置，密钥只由服务端读取。可以先试「A 轮前、做人形本体，团队最好有海外背景」，再问「只要清华校友的」或「对比前两家」。

默认使用现有 `matching_data/` 参考数据。联调管理员导出时，将 `USER_RADAR_SNAPSHOT` 指向管理员系统 `/api/export` 导出的 ZIP 或其解压后的数据目录，再重启服务。请求只读用户端配置的快照。快照缺少字段对应的原文链接时，页面显示可用的档案字段和工作簿位置。管理员更新字段只有文章来源链接时，页面显示该链接和快照记录。

## 匹配步骤与分数

1. 模型把自然语言转换成结构化条件和语义条件，标记每项是否为硬条件并给出 1–5 的权重。追问会携带上一轮条件和结果，用于区分追加筛选、对比、解释和事实问答。
2. 程序按词表处理赛道、轮次、地区、场景、技术路线、投资方和商业模式。硬条件缺少依据时排除。明确出现较晚轮次的历史记录时，对早期轮次做保守判断。
3. 自由条件使用向量相似度从结构化候选中召回最多 24 家。模型逐家给出命中、未满足或证据不足的判断。程序校验引用是否逐字存在于对应公司的档案字段，排序时只给有依据的命中项计分。
4. Match Score = 100 × 命中项权重总和 ÷ 全部偏好项权重总和，四舍五入。结果按分数降序显示，分数含义为相对匹配度，非投资成功概率。追问中的公司事实也经过同一字段引文校验。

## 验收记录

已通过两种输入的同一套自动验收。第一种使用交付包的 60 家公司，第二种由管理员 SQLite 初始化并实际导出 ZIP 后读取。两次均验证了硬条件筛选、语义追问、两家公司对比、卡片解释、来源字段、伪造引文拦截、无结果、会话隔离、无法解析的输入和模型配置缺失时的 503。模型响应在进程内模拟，真实模型的准确率、延迟和成本待组内账号联调。

## 接入项目

将 `src/user_radar/` 和 `verify_user_radar.py` 放入项目独立用户端分支。交付包里附带既有参考数据便于独立重现。已有仓库可继续使用原有 `matching_data/`。

- `GET /api/matching/info` 返回公司数、快照版本和模型配置状态。
- `POST /api/matching/query` 接收 `{"query":"…","follow_up":false}`。追问将 `follow_up` 改为 `true`，浏览器保留同源会话 Cookie。
- `GET /api/matching/companies/{id}` 返回公司档案字段和来源。

独立 Render 测试服务可用 Python Web Service。构建命令为 `pip install gunicorn`，启动命令为 `gunicorn --bind 0.0.0.0:$PORT --workers 1 --threads 4 --timeout 90 src.user_radar.server:application`，健康检查为 `/healthz`。测试站设置 `USER_RADAR_DEMO_PASSWORD`，用户名为 `demo`。组内测试会话暂存在单进程内存中，服务重启后重新搜索。

11 月 28 日起按组内分工接 Figma 用户站和其余 PRD 功能。届时由正式账号身份控制 F5 游客限制、免费用户一次额度及管理员不限次，并接入收藏与用户私有公司。当前测试界面用来独立验收 F5。
