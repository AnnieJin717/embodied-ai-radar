"""Normalize reported valuations and compare only compatible amounts."""
from dataclasses import dataclass
from decimal import Decimal
import re
import unicodedata


NUMBER = r"(?:\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?|百|十)"
UNIT = r"(?:万亿|亿元?|万元?|百万|千万|billion|million|bn|mn|[bm亿万元])"
CURRENCY = r"(?:人民币|美元|美金|港元|港币|rmb|cny|usd|hkd|港幣|[¥$])"
AMOUNT = rf"(?:(?P<prefix>{CURRENCY})\s*)?(?P<magnitude>{NUMBER})\s*(?P<unit>{UNIT})?\s*(?P<suffix>{CURRENCY})?"
QUERY = re.compile(
    rf"(?P<op>严格低于|不高于|不超过|不低于|不少于|小于等于|大于等于|低于|小于|少于|高于|大于|超过|至少|至多|"
    rf"no more than|at most|no less than|at least|under|below|less than|above|over|greater than|<=|>=|<|>|≤|≥)\s*{AMOUNT}",
    re.I,
)
FIELD = re.compile(r"估值|\bvaluations?\b|\bvalued\s+at\b", re.I)
POSTFIX = re.compile(rf"{AMOUNT}\s*(?P<boundary>及以下|及以上|以下|以上|以内)", re.I)
RANGE = re.compile(
    rf"(?:在|介于)\s*(?P<begin>{NUMBER})\s*(?P<begin_unit>{UNIT})?\s*(?P<begin_ccy>{CURRENCY})?"
    rf"\s*[-–—~至到和]\s*{AMOUNT}\s*(?:之间|内)?", re.I,
)
OP = {
    "lt": {"严格低于", "低于", "小于", "少于", "under", "below", "less than", "<"},
    "le": {"不高于", "不超过", "小于等于", "至多", "no more than", "at most", "<=", "≤"},
    "gt": {"高于", "大于", "超过", "above", "over", "greater than", ">"},
    "ge": {"不低于", "不少于", "大于等于", "至少", "no less than", "at least", ">=", "≥"},
}
SCALE = {"万亿": 10**12, "亿": 10**8, "万": 10**4, "千万": 10**7, "百万": 10**6,
         "billion": 10**9, "b": 10**9, "bn": 10**9, "million": 10**6, "m": 10**6, "mn": 10**6}
CURRENCIES = {"人民币": "CNY", "cny": "CNY", "rmb": "CNY", "¥": "CNY", "美元": "USD",
              "美金": "USD", "usd": "USD", "$": "USD", "港元": "HKD", "港币": "HKD", "港幣": "HKD", "hkd": "HKD"}
REPORT_AMOUNT = re.compile(
    rf"(?P<qualifier>不低于|不超过|超过|突破|低于|上限|下限|至少|至多|大于|小于|超|破|约合|约|近)?\s*"
    rf"(?:(?P<range_start>{NUMBER})\s*(?P<range_unit>{UNIT})?\s*[-–—~至到]\s*)?{AMOUNT}",
    re.I,
)


def normalize(text):
    return unicodedata.normalize("NFKC", text)


def amount(number, unit, prefix, suffix):
    if not (unit or prefix or suffix):
        return None
    tokens = [CURRENCIES[t.casefold()] for t in (prefix, suffix) if t]
    if len(set(tokens)) > 1:
        return None
    value = Decimal({"百": "100", "十": "10"}.get(number, number.replace(",", "")))
    suffix_unit = (unit or "").casefold().removesuffix("元")
    return value * SCALE.get(suffix_unit, 1), tokens[0] if tokens else "CNY"


def query_rules(query, previous=None):
    """Return supported numeric rules and the residual query for other filters."""
    text = normalize(query)
    field = FIELD.search(text)
    old = [r for r in (previous or {}).get("criteria", []) if r["field"] == "valuation"]
    implicit = old and re.match(r"^\s*(?:请)?(?:改成|改为|放宽到|收紧到|换成|make it|change to)", text, re.I)
    if not (field or implicit):
        return [], text
    if re.search(r"或|\bor\b|而非|不是|不要", text, re.I):
        raise ValueError("Disjunctive or negated valuation condition.")
    bound_text = text[field.end():] if field else text[implicit.end():]
    # A bound must be adjacent to the valuation field or explicitly linked to another bound.
    simple_text = bound_text.lstrip(" 为是：:")
    first = QUERY.match(simple_text)
    postfix = POSTFIX.match(simple_text) if not first else None
    interval = RANGE.match(simple_text) if not (first or postfix) else None
    if implicit and not (first or postfix or interval) and len(old) == 1:
        implied = re.compile(AMOUNT, re.I).match(simple_text)
        if implied and (implied["unit"] or implied["prefix"] or implied["suffix"]):
            first = implied
    first = first or postfix or interval
    if not first:
        if QUERY.search(bound_text) or re.search(r"介于|之间|区间|[\d百十]+\s*[亿万]", bound_text):
            raise ValueError("Unsupported valuation syntax.")
        return [], text
    start = (field.start() if field else 0)
    offset = len(text) - len(simple_text)
    end = offset + first.end()
    filters = [first]
    connector = re.match(r"\s*(?:且|并且|同时|and|[，,、])\s*(?:估值\s*|valuation\s*)?", text[end:], re.I)
    if connector and (second := QUERY.match(text[end + connector.end():])):
        filters.append(second)
        end += connector.end() + second.end()
    rules = []
    for match in filters:
        parts = match.groupdict()
        parsed = amount(parts["magnitude"], parts["unit"], parts["prefix"], parts["suffix"])
        if parsed is None:
            raise ValueError("Valuation needs amount units.")
        amount_value, currency = parsed
        if match is interval:
            start_value = amount(parts["begin"], parts["begin_unit"] or parts["unit"],
                                 parts["begin_ccy"] or parts["prefix"], parts["suffix"])
            if not start_value or start_value[1] != currency or start_value[0] > amount_value:
                raise ValueError("Invalid valuation range.")
            rules.append(dict(label="估值区间下限 " + parts["begin"] + (parts["begin_unit"] or parts["unit"] or ""),
                              field="valuation", op="ge", values=[], amount=str(start_value[0]),
                              currency=currency, required=True, weight=3))
            op = "le"
        elif match is postfix:
            op = "ge" if parts["boundary"].endswith("以上") else "le"
        elif "op" not in parts:
            op = old[0]["op"]
        else:
            op = next(key for key, labels in OP.items() if parts["op"].casefold() in labels)
        label = match[0].strip()
        if "op" not in parts and match is not interval and match is not postfix:
            label = {"lt": "低于", "le": "不超过", "gt": "高于", "ge": "至少"}[op] + label
        rules.append(dict(label="估值" + label, field="valuation", op=op, values=[],
                          amount=str(amount_value), currency=currency, required=True, weight=3))
    if len({rule["currency"] for rule in rules}) != 1:
        raise ValueError("Mixed valuation currencies.")
    return rules, text[:start] + " " + text[end:]


@dataclass(frozen=True)
class ReportedValue:
    lower: Decimal | None
    upper: Decimal | None
    lower_included: bool
    upper_included: bool
    currency: str
    excerpt: str

    def satisfies(self, op, limit):
        if op in {"lt", "le"}:
            return self.upper is not None and (
                self.upper < limit or (self.upper == limit and (op == "le" or not self.upper_included)))
        return self.lower is not None and (
            self.lower > limit or (self.lower == limit and (op == "ge" or not self.lower_included)))


def reported(text):
    # The canonical snapshot ranks the primary disclosure first. Ignore background dates,
    # later rumors or targets, and historical values in parenthetical notes.
    text = normalize(text or "")
    primary = re.split(r"[;\n]", re.sub(r"\([^()]*\)", "", text), maxsplit=1)[0].strip()
    if re.search(r"未公开|未披露|不详|市值|目标估值|预计|\b(?:market cap|undisclosed)\b", primary, re.I):
        return None
    if "上市后估值" in primary:
        primary = primary[primary.index("上市后估值"):]
    elif "投后" in primary and "投前" in primary:
        primary = primary[primary.index("投后"):]
    if re.search(r"欧元|日元|新加坡元|英镑|韩元|澳元|加元|瑞士法郎|\b(?:EUR|GBP|JPY|SGD|CAD|AUD|KRW)\b", primary, re.I):
        return None
    matches = []
    for match in REPORT_AMOUNT.finditer(primary):
        parts = match.groupdict()
        parsed = amount(parts["magnitude"], parts["unit"], parts["prefix"], parts["suffix"])
        if parsed is not None:
            matches.append((parts, parsed))
    if len(matches) != 1:
        return None
    parts, (value, currency) = matches[0]
    qualifier = parts["qualifier"]
    if parts["range_start"]:
        start_parts = amount(parts["range_start"], parts["range_unit"] or parts["unit"],
                             parts["prefix"], parts["suffix"])
        if start_parts is None or start_parts[0] > value or qualifier not in {None, "约"}:
            return None
        return ReportedValue(start_parts[0], value, True, True, currency, primary)
    if qualifier in {"超", "超过", "突破", "破", "大于", "不低于", "至少", "下限"}:
        return ReportedValue(value, None, qualifier in {"不低于", "至少", "下限"}, False, currency, primary)
    if qualifier in {"不超过", "低于", "上限", "小于", "至多"}:
        return ReportedValue(None, value, False, qualifier in {"不超过", "上限", "至多"}, currency, primary)
    return ReportedValue(value, value, True, True, currency, primary)
