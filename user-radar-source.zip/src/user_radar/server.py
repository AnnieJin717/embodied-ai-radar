"""Independent F5 demo. Run with python -m src.user_radar.server."""
import base64
import hmac
import json
import os
import re
import secrets
import time
from collections import OrderedDict
from functools import lru_cache
from pathlib import Path
from socketserver import ThreadingMixIn
from threading import Lock
from wsgiref.simple_server import WSGIServer, make_server
from zipfile import BadZipFile

from .matching import InvalidPreference, Model, Unavailable, Workflow
from .snapshot import FIELDS, Snapshot


HERE = Path(__file__).parent
SNAPSHOT = Path(os.getenv("USER_RADAR_SNAPSHOT", HERE.parents[1] / "matching_data"))
COOKIE = re.compile(r"(?:^|;\s*)radar_session=([A-Za-z0-9_-]{43})(?:;|$)")
STATIC = {"/": ("index.html", "text/html"), "/demo.css": ("demo.css", "text/css"),
          "/demo.js": ("demo.js", "application/javascript")}
LOCK = Lock()
SESSIONS = OrderedDict()


@lru_cache(maxsize=1)
def workflow():
    return Workflow(Snapshot(SNAPSHOT), Model())


def session(sid):
    with LOCK:
        record = SESSIONS.get(sid)
        if record and time.monotonic() - record[0] < 3600:
            return record[1]
        return None


def remember(sid, result):
    with LOCK:
        SESSIONS[sid] = (time.monotonic(), result)
        SESSIONS.move_to_end(sid)
        while len(SESSIONS) > 128:
            SESSIONS.popitem(last=False)


def json_reply(body, status="200 OK", headers=()):
    return status, "application/json", json.dumps(body, ensure_ascii=False).encode(), headers


def authenticated(environ):
    password = os.getenv("USER_RADAR_DEMO_PASSWORD")
    if not password:
        return environ.get("REMOTE_ADDR") in {"127.0.0.1", "::1"} and not environ.get("HTTP_X_FORWARDED_FOR")
    prefix, _, value = environ.get("HTTP_AUTHORIZATION", "").partition(" ")
    if prefix.casefold() != "basic":
        return False
    try:
        supplied = base64.b64decode(value, validate=True)
    except ValueError:
        return False
    expected = ("demo:" + password).encode()
    return hmac.compare_digest(supplied, expected)


def dispatch(environ):
    route, method = environ["PATH_INFO"], environ["REQUEST_METHOD"]
    if route == "/healthz" and method == "GET":
        return json_reply({"status": "ok"})
    if not authenticated(environ):
        return json_reply({"error": "demo_login_required"}, "401 Unauthorized",
                          [("WWW-Authenticate", 'Basic realm="Radar matching demo", charset="UTF-8"')])
    if method == "GET" and route in STATIC:
        file, content_type = STATIC[route]
        return "200 OK", content_type, (HERE / "static" / file).read_bytes(), ()
    if method == "GET" and route == "/api/matching/info":
        data = workflow().snapshot
        return json_reply({"companies": len(data.companies), "snapshot": data.kind,
                           "version": data.version[:12], "live_model_configured": bool(
                               workflow().model.key and workflow().model.chat_model and workflow().model.embedding_model)})
    if method == "GET" and route.startswith("/api/matching/companies/"):
        cid = route.rsplit("/", 1)[-1]
        if company := workflow().snapshot.companies.get(cid):
            return json_reply({"name": company["name"], "facts": workflow().facts[cid], "labels": FIELDS})
    if method == "POST" and route == "/api/matching/query":
        try:
            size = int(environ.get("CONTENT_LENGTH") or 0)
            if environ.get("CONTENT_TYPE", "").split(";")[0] != "application/json" or not 1 <= size <= 16_384:
                raise ValueError
            payload = json.loads(environ["wsgi.input"].read(size))
            query = payload["query"].strip()
            if not 1 <= len(query) <= 1200:
                raise ValueError
        except (AttributeError, KeyError, UnicodeError, ValueError, TypeError):
            return json_reply({"error": "invalid_query"}, "400 Bad Request")
        cookie = COOKIE.search(environ.get("HTTP_COOKIE", ""))
        previous = session(cookie[1]) if cookie else None
        if payload.get("follow_up") is True and not previous:
            return json_reply({"error": "session_expired"}, "409 Conflict")
        if payload.get("follow_up") is not True:
            previous = None
        result = workflow().transform(query, previous)
        sid = cookie[1] if cookie and previous else secrets.token_urlsafe(32)
        secure = "; Secure" if environ.get("wsgi.url_scheme") == "https" or os.getenv("RENDER") else ""
        remember(sid, result)
        return json_reply(result, headers=[("Set-Cookie", f"radar_session={sid}; Path=/; HttpOnly; SameSite=Strict{secure}")])
    return json_reply({"error": "not_found"}, "404 Not Found")


def application(environ, start_response):
    try:
        status, content_type, body, headers = dispatch(environ)
    except InvalidPreference:
        status, content_type, body, headers = json_reply({"error": "preference_unreadable"}, "422 Unprocessable Entity")
    except (Unavailable, OSError, ValueError, BadZipFile) as exc:
        print(f"Matching request unavailable: {type(exc).__name__}", flush=True)
        status, content_type, body, headers = json_reply({"error": "matching_unavailable"}, "503 Service Unavailable")
    start_response(status, [("Content-Type", content_type + "; charset=utf-8"),
                            ("Content-Length", str(len(body))), ("Cache-Control", "no-store"),
                            ("X-Content-Type-Options", "nosniff"),
                            ("Content-Security-Policy", "default-src 'self'; frame-ancestors 'none'; base-uri 'none'"),
                            *headers])
    return [body]


class ThreadedServer(ThreadingMixIn, WSGIServer):
    daemon_threads = True


def main():
    host = os.getenv("USER_RADAR_HOST", "127.0.0.1")
    if host not in {"127.0.0.1", "::1"} and not os.getenv("USER_RADAR_DEMO_PASSWORD"):
        raise SystemExit("Set USER_RADAR_DEMO_PASSWORD before binding to a public interface.")
    workflow()
    with make_server(host, int(os.getenv("PORT", "8013")), application, server_class=ThreadedServer) as server:
        print(f"User radar matching demo listening on {host}:{server.server_port}", flush=True)
        server.serve_forever()


if __name__ == "__main__":
    main()
