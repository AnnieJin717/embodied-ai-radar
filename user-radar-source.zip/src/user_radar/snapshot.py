"""Read the administrator's user-facing export without writing to their database."""
import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path
from urllib.parse import urlsplit
from zipfile import ZipFile


FIELDS = {
    "name": "公司名称", "headquarters": "总部", "primary_tracks": "一级赛道",
    "sub_tracks": "二级细分", "funding_stage": "融资阶段", "funding_history": "融资历史",
    "historical_investors": "历史投资方", "business_description": "主营业务",
    "products": "主要产品", "technology_routes": "技术路线",
    "application_scenarios": "应用场景", "business_models": "商业模式",
    "team_education": "团队教育背景", "team_work": "团队工作背景",
    "founders": "创始人", "major_customers": "标杆客户", "shipments": "出货量",
    "revenue": "营收", "valuation": "估值", "employee_scale": "员工规模",
}
FILTERS = frozenset(("headquarters", "primary_tracks", "sub_tracks", "funding_stage",
                     "historical_investors", "technology_routes", "application_scenarios",
                     "business_models"))
REQUIRED = ("companies", "taxonomy")
OPTIONAL = ("sources", "team_members", "funding_events", "admin_events", "events")


def public_url(value):
    try:
        link = urlsplit(value or "")
        if link.scheme in {"http", "https"} and link.hostname and not link.username and not link.password:
            return value
    except ValueError:
        pass
    return None


def clean(value):
    if isinstance(value, list):
        return "；".join(str(item).strip() for item in value if item)
    if isinstance(value, dict):
        return clean(value.get("value"))
    return str(value).strip() if value is not None else ""


def source_location(row, field):
    provenance = row.get("provenance") or {}
    cell = (provenance.get("cells") or {}).get(field) or {}
    return {
        "location": " / ".join(str(x) for x in (provenance.get("workbook"), provenance.get("sheet"),
                                                 cell.get("coordinate")) if x) if cell else "",
        "excerpt": clean(cell.get("raw_value"))[:260],
    }


def canonical(value):
    return re.sub(r"[^\w+\-\u4e00-\u9fff]", "", value.casefold())


def read_tables(path):
    tables = {}
    with ZipFile(path) if path.is_file() else _directory(path) as get:
        for name in (*REQUIRED, *OPTIONAL):
            try:
                if isinstance(get, ZipFile):
                    candidates = (f"matching_data/{name}.json", f"{name}.json")
                    archive_name = next((entry for entry in candidates if entry in get.namelist()), None)
                    if archive_name is None:
                        raise FileNotFoundError(name)
                    if get.getinfo(archive_name).file_size > 10_000_000:
                        raise ValueError(f"Snapshot table too large: {name}")
                    raw = get.read(archive_name)
                else:
                    raw = get(name)
            except FileNotFoundError:
                if name in REQUIRED:
                    raise ValueError(f"Snapshot table missing: {name}") from None
                continue
            rows = json.loads(raw)
            if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
                raise ValueError(f"Invalid snapshot table: {name}")
            tables[name] = rows
    return tables


class _directory:
    def __init__(self, path):
        self.path = path

    def __enter__(self):
        return lambda name: (self.path / f"{name}.json").read_bytes()

    def __exit__(self, *args):
        return False


class Snapshot:
    def __init__(self, directory_or_zip):
        path = Path(directory_or_zip)
        tables = read_tables(path)
        self.kind = "admin_export" if path.is_file() or "admin_events" in tables else "baseline"
        self.version = hashlib.sha256(json.dumps(tables, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        self.options = defaultdict(set)
        self.sources = defaultdict(list)
        self.team = defaultdict(list)
        self.funding = defaultdict(list)
        for row in tables.get("sources", []):
            if public_url(row.get("url")):
                self.sources[row.get("company_id")].append(row)
        for row in tables.get("team_members", []):
            self.team[row.get("company_id")].append(row)
        for row in tables.get("funding_events", []):
            self.funding[row.get("company_id")].append(row)
        for row in tables["taxonomy"]:
            if row.get("field") in FILTERS and isinstance(row.get("label"), str):
                self.options[row["field"]].add(row["label"])
        self.companies = {}
        seen = set()
        for row in tables["companies"]:
            cid = row.get("id")
            if not isinstance(cid, str) or not cid or not clean(row.get("name")) or cid in seen:
                raise ValueError("Snapshot company ID/name invalid or duplicated")
            seen.add(cid)
            if row.get("review_status") in {"pending", "needs_review", "draft", "待复核"}:
                continue
            self.companies[cid] = row
            for field in FILTERS:
                self.options[field].update(self.values(row, field))
        if not self.companies:
            raise ValueError("No public companies in snapshot")

    def values(self, row, field):
        raw = row.get(field)
        if field == "headquarters":
            return [piece.strip() for piece in re.split(r"[/、]", re.split(r"[（(;；]", clean(raw))[0]) if piece.strip()]
        return [clean(item) for item in raw if clean(item)] if isinstance(raw, list) else ([clean(raw)] if clean(raw) else [])

    def facts(self, row):
        facts = {}
        for field in FIELDS:
            if field.startswith("team_"):
                key = {"team_education": "education", "team_work": "work_history"}[field]
                entries = [{"value": f"{clean(person.get('name'))}：{clean(person[key])}"[:1400],
                            **source_location(person, key), "urls": []}
                           for person in self.team[row["id"]] if clean(person.get(key))]
            elif value := clean(row.get(field)):
                names = {canonical(field), canonical(FIELDS[field])}
                links = [s for s in self.sources[row["id"]]
                         if any(canonical(label) in names
                                for label in re.split(r"[,、;/；，|]", clean(s.get("supported_fields"))))]
                location = source_location(row, field)
                if any(s.get("source_limits") == "Manually reviewed article extraction" for s in links):
                    location = {"location": "Admin review", "excerpt": ""}
                entries = [{"value": value[:2400], **location, "urls": [
                    {"url": s["url"], "date": clean(s.get("publication_date")),
                     "scope": clean(s.get("source_limits"))} for s in links[:5]
                ]}]
            else:
                entries = []
            if entries:
                facts[field] = entries
        return facts

    def taxonomy(self):
        return {field: sorted(self.options[field]) for field in sorted(FILTERS)}
