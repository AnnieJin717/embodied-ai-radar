"""User-side investment matching workflow."""
