const copy = {
  zh: {
    brand: "具身项目雷达", title: "AI 智能匹配", "preference-label": "你的投资偏好", submit: "开始匹配",
    "results-title": "匹配结果", "score-note": "相对匹配度，非投资成功概率", "follow-up-label": "继续追问", ask: "发送",
    preference: "例：A 轮前、做人形本体，团队最好有海外背景",
    question: "例：只要清华校友的，或对比前两家",
    baseline: "公司参考数据", admin_export: "管理员导出快照", count: "家公司", pending: "正在匹配，请稍候…",
    unavailable: "智能匹配服务暂不可用，请稍后重试。",
    unreadable: "这组条件暂时无法处理。试试“创始人是清华大学毕业”或“A 轮前、做人形本体”。",
    expired: "这次会话已过期，请重新匹配。",
    empty: "库内暂无匹配公司。试试放宽条件。",
    covered: "已评估", eligible: "家通过结构化筛选", met: "命中", unmet: "未满足",
    unknown: "证据不足", why: "为什么是它", detail: "查看公司档案", noEvidence: "当前档案没有足够证据回答。",
    noLinks: "档案未提供对应字段的公开链接", links: "原始来源", missingModel: " · 档案匹配模式",
    localMode: "按档案字段筛选。已应用条件",
    noFacts: "未公开", archive: "档案字段"
  },
  en: {
    brand: "Embodied AI Radar", title: "AI matching", "preference-label": "Your investment preferences", submit: "Find matches",
    "results-title": "Matches", "score-note": "Relative fit, not probability of investment success", "follow-up-label": "Ask a follow-up", ask: "Send",
    preference: "Example: Pre-Series A humanoid robotics, preferably with international team experience",
    question: "Example: Only teams with Tsinghua alumni, or compare the first two",
    baseline: "Company reference data", admin_export: "Admin snapshot", count: " companies", pending: "Matching in progress…",
    unavailable: "Matching is temporarily unavailable. Please try again later.",
    unreadable: "This query could not be interpreted. Try “founders graduated from Tsinghua” or “humanoid robotics before Series A”.",
    expired: "This session has expired. Start a new search.",
    empty: "No matching companies were found. Try broadening your criteria.",
    covered: "Evaluated", eligible: " passed structured filters", met: "Matched", unmet: "Not met",
    unknown: "Insufficient evidence", why: "Why this company?", detail: "View dossier", noEvidence: "The dossiers do not contain enough evidence to answer.",
    noLinks: "No public link recorded for this field", links: "Source", missingModel: " · Dossier matching",
    localMode: "Matched against dossier fields. Applied filters",
    noFacts: "Undisclosed", archive: "Dossier field"
  }
};
const byId = id => document.getElementById(id);
let locale = localStorage.getItem("radar-language") === "en" ? "en" : "zh";
let lastResult, dataInfo, lastError;
const t = key => copy[locale][key];

function element(tag, value, className) {
  const node = document.createElement(tag);
  if (value != null) node.textContent = value;
  if (className) node.className = className;
  return node;
}

function evidence(item) {
  const section = element("div");
  section.append(element("strong", item.label));
  section.append(element("blockquote", item.quote));
  if (item.location) section.append(element("small", item.location));
  for (const source of item.urls || []) {
    const url = new URL(source.url);
    if (!["http:", "https:"].includes(url.protocol)) continue;
    const row = element("p");
    const link = element("a", t("links") + (source.date ? " · " + source.date : ""));
    link.href = url.href;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    row.append(link);
    if (source.scope) row.append(document.createTextNode(" · " + source.scope));
    section.append(row);
  }
  if (!item.urls?.length) section.append(element("p", t("noLinks")));
  return section;
}

function card(result) {
  const item = element("article");
  const heading = element("div", null, "card-header");
  heading.append(element("h3", result.name), element("span", result.score + "%", "score"));
  item.append(heading, element("p", result.summary || t("noFacts")));
  const list = element("ul");
  for (const check of result.checks) {
    const label = t(check.status) + " · " + check.label;
    list.append(element("li", label + (check.evidence ? " · " + check.evidence.label : "")));
  }
  item.append(list);
  const explanation = element("details");
  explanation.append(element("summary", t("why")));
  for (const check of result.checks) if (check.evidence) explanation.append(evidence(check.evidence));
  item.append(explanation);
  const dossier = element("details");
  dossier.append(element("summary", t("detail")));
  dossier.addEventListener("toggle", async () => {
    if (!dossier.open || dossier.childElementCount > 1) return;
    try {
      const response = await fetch("/api/matching/companies/" + encodeURIComponent(result.id));
      if (!response.ok) throw new Error();
      const detail = await response.json();
      for (const [field, entries] of Object.entries(detail.facts)) {
        for (const entry of entries) {
          const label = detail.labels[field] ?? field;
          dossier.append(evidence({...entry, label, quote: entry.value}));
        }
      }
    } catch {
      dossier.append(element("p", t("unavailable")));
    }
  });
  item.append(dossier);
  return item;
}

function draw() {
  if (dataInfo) byId("snapshot").textContent = t(dataInfo.snapshot) + " · " + dataInfo.companies + " " + t("count") +
    (dataInfo.live_model_configured ? "" : t("missingModel"));
  if (lastError) byId("status").textContent = t(lastError);
  if (!lastResult) return;
  const {results, answer, action, criteria, mode, evaluated_count, structured_count} = lastResult;
  byId("output").hidden = false;
  byId("cards").replaceChildren(...results.map(card));
  if (!results.length) byId("cards").append(element("p", t("empty")));
  if (!lastError) byId("status").textContent = mode === "local" ?
    t("localMode") + " · " + criteria.map(item => item.label).join(" / ") :
    t("covered") + " " + evaluated_count + " / " + structured_count + " " + t("eligible");
  byId("answer").replaceChildren();
  if (["compare", "explain", "question"].includes(action)) {
    if (!answer.length) byId("answer").append(element("p", t("noEvidence")));
    for (const fact of answer) {
      const article = element("article");
      article.append(element("h3", fact.name), evidence(fact));
      byId("answer").append(article);
    }
  }
}

function translate() {
  document.documentElement.lang = locale === "en" ? "en" : "zh-CN";
  for (const id of ["brand", "title", "preference-label", "submit", "results-title", "score-note", "follow-up-label", "ask"]) {
    byId(id).textContent = t(id);
  }
  byId("language").textContent = locale === "zh" ? "EN" : "中文";
  for (const id of ["preference", "question"]) byId(id).placeholder = t(id);
  draw();
}

async function run(followUp) {
  const input = byId(followUp ? "question" : "preference");
  const query = input.value.trim();
  if (!query) return;
  byId("submit").disabled = byId("ask").disabled = true;
  byId("status").textContent = t("pending");
  lastError = null;
  try {
    const response = await fetch("/api/matching/query", {method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({query, follow_up: followUp})});
    if (!response.ok) throw new Error({409: "expired", 422: "unreadable"}[response.status] || "unavailable");
    lastResult = await response.json();
    if (followUp) input.value = "";
  } catch (error) {
    lastError = ["expired", "unreadable"].includes(error.message) ? error.message : "unavailable";
  } finally {
    byId("submit").disabled = byId("ask").disabled = false;
    draw();
  }
}

byId("language").addEventListener("click", () => {
  locale = locale === "zh" ? "en" : "zh";
  localStorage.setItem("radar-language", locale);
  translate();
});
byId("search").addEventListener("submit", event => {event.preventDefault(); run(false);});
byId("follow-up").addEventListener("submit", event => {event.preventDefault(); run(true);});
translate();
fetch("/api/matching/info").then(response => response.ok ? response.json() : Promise.reject())
  .then(info => {dataInfo = info; draw();}).catch(() => {lastError = "unavailable"; draw();});
