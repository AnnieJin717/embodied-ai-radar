"""Evidence-based matching when the hosted model is unavailable."""
import re

from .snapshot import canonical, clean, source_location


SCHOOLS = {
    "清华大学": r"清华(?:大学)?|\btsinghua(?: university)?\b",
    "北京大学": r"北京大学|北大|\bpeking university\b",
    "浙江大学": r"浙江大学|浙大|\bzhejiang university\b",
    "上海交通大学": r"上海交通大学|上海交大|上交大|\bshanghai jiao tong university\b",
    "斯坦福大学": r"斯坦福(?:大学)?|\bstanford(?: university)?\b",
    "麻省理工学院": r"麻省理工(?:学院)?|\bmit\b",
}
FOUNDER = re.compile(r"创[始办]人|创立者|\b(?:co[- ]?)?founders?\b", re.I)
DEGREE = re.compile(r"本科|学士|硕士|博士(?!后)|毕业|\b(?:graduate[d]?|bachelor|master|ph\.?d\.?)\b", re.I)
INCOMPLETE = re.compile(r"肄业|退学|在读|就读中|博士后|访学|未毕业|未获|候选人|学历层次不详|postdoc|visiting|candidate|in progress", re.I)
OVERSEAS = re.compile(r"美国|英国|德国|法国|加拿大|新加坡|澳大利亚|斯坦福|麻省理工|卡内基梅隆|伯克利|哈佛|剑桥大学|牛津大学|南加州大学|纽约大学|帝国理工|南洋理工|\b(?:Stanford|MIT|Harvard|Berkeley|Oxford)\b", re.I)
HUMANOID = re.compile(r"人形(?:机器人)?本体|\bhumanoid(?: robotics?| bodies)?\b", re.I)
STAGE = re.compile(r"(?:\b(?:series\s+)?([A-D])\s*轮?\s*(前|及以前|及以下)|\b(before|up to|pre[- ]series)\s*(?:series\s*)?([A-D])\b)", re.I)


def education_evidence(snapshot, company, rule):
    founders = {canonical(value) for value in snapshot.values(company, "founders")}
    school = re.compile(SCHOOLS[rule["school"]], re.I) if rule["school"] else OVERSEAS
    for person in snapshot.team[company["id"]]:
        name = clean(person.get("name"))
        canonical_name = canonical(re.split(r"[（(]", name, maxsplit=1)[0])
        role = clean(person.get("role"))
        is_founder = canonical_name in founders or bool(FOUNDER.search(role))
        if rule["founder"] and not is_founder:
            continue
        education = person.get("education")
        entries = education if isinstance(education, list) else re.split(r"[；;\n]", clean(education))
        for entry in entries:
            entry = clean(entry)
            if not school.search(entry):
                continue
            if rule["school"] and (not DEGREE.search(entry) or INCOMPLETE.search(entry)):
                continue
            attribution = f"（{role}）" if role else "（创始人）" if is_founder else ""
            return {"field": "team_education", "label": "创始人教育背景" if rule["founder"] else "团队教育背景",
                    "quote": f"{name}{attribution}：{entry}", **source_location(person, "education"), "urls": []}
    return None


def rules_for(query, taxonomy, previous):
    from .matching import InvalidPreference, STAGES

    if re.search(r"排除|不要|非清华|不含|不是|不考虑|除了|\b(?:exclude|without|not)\b", query, re.I):
        raise InvalidPreference("A negative filter needs the hosted model.")
    matches = []

    def add(label, field, op, values, **extra):
        matches.append(dict(label=label, field=field, op=op, values=values,
                            required=True, weight=3, **extra))

    if HUMANOID.search(query) and "人形机器人本体" in taxonomy["sub_tracks"]:
        add("人形机器人本体", "sub_tracks", "in", ["人形机器人本体"])
    if hit := STAGE.search(query):
        zh, bound, en, english_stage = hit.groups()
        value = (zh or english_stage).upper()
        if value in STAGES:
            inclusive = bound in {"及以前", "及以下"} or (en or "").lower() == "up to"
            add(f"{value} 轮{'及以前' if inclusive else '前'}", "funding_stage",
                "at_most" if inclusive else "before", [value])
    schools = [school for school, pattern in SCHOOLS.items() if re.search(pattern, query, re.I)]
    if len(schools) > 1:
        raise InvalidPreference("Multiple schools need the hosted model.")
    if schools or re.search(r"海外背景|海外教育|international (?:team |educational )?background|studied abroad", query, re.I):
        founder = bool(FOUNDER.search(query))
        school = schools[0] if schools else None
        label = ("创始人" if founder else "团队成员") + (f"具备{school}学历" if school else "有海外教育背景")
        add(label, "local_education", "education", [], school=school, founder=founder)
        matches[-1]["required"] = not bool(re.search(r"最好|优先|preferably|preferred", query, re.I))
    for field in ("headquarters", "application_scenarios", "technology_routes", "business_models", "sub_tracks", "primary_tracks"):
        labels = taxonomy[field]
        if "sub_tracks" in {rule["field"] for rule in matches} and field == "primary_tracks":
            continue
        if field in {rule["field"] for rule in matches}:
            continue
        labels = [label for label in labels if 2 <= len(label) <= 45 and (
            re.search(r"(?<![\w-])" + re.escape(label) + r"(?![\w-])", query, re.I)
            if label.isascii() else label in query)]
        if labels:
            label = max(labels, key=len)
            add(label, field, "in", [label])
    if not matches:
        raise InvalidPreference("Unsupported local query.")
    if previous:
        if any(rule["field"] == "semantic" for rule in previous["criteria"]):
            raise InvalidPreference("Refining this search needs the hosted model.")
        changed = {rule["field"] for rule in matches}
        matches = [rule for rule in previous["criteria"] if rule["field"] not in changed] + matches
    return matches


def follow_up(workflow, query, previous):
    from .matching import citation

    compare = re.search(r"对比|比较|\bcompare\b", query, re.I)
    explain = re.search(r"为什么|解释|\bwhy\b|\bexplain\b", query, re.I)
    if not previous or not (compare or explain):
        return None
    answer = []
    for row in previous["results"][:2 if compare else 1]:
        evidence = [check["evidence"] for check in row["checks"] if check["status"] == "met"]
        if compare:
            evidence += [citation(workflow.facts[row["id"]], field)
                         for field in ("funding_stage", "business_description")]
        answer.extend({"id": row["id"], "name": row["name"], **item} for item in evidence if item)
    return {**previous, "action": "compare" if compare else "explain", "answer": answer, "mode": "local"}
